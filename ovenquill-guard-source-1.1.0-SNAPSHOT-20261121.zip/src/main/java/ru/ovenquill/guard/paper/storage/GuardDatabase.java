package ru.ovenquill.guard.paper.storage;

import ru.ovenquill.guard.common.AuditEvent;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public final class GuardDatabase implements AutoCloseable {
    private final Path path;
    private Connection connection;
    public GuardDatabase(Path path) { this.path = path; }

    public synchronized void initialize() throws Exception {
        Files.createDirectories(path.getParent());
        connection = DriverManager.getConnection("jdbc:sqlite:" + path.toAbsolutePath());
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL");
            s.execute("PRAGMA synchronous=FULL");
            s.execute("CREATE TABLE IF NOT EXISTS player_state(player_uuid TEXT PRIMARY KEY, session_uuid TEXT NOT NULL, phase TEXT NOT NULL, snapshot TEXT NOT NULL, updated_at INTEGER NOT NULL)");
            s.execute("CREATE TABLE IF NOT EXISTS audit_queue(event_id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0)");
        }
    }

    public synchronized void saveState(UUID player, UUID session, String phase, String snapshot) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("INSERT INTO player_state VALUES(?,?,?,?,?) ON CONFLICT(player_uuid) DO UPDATE SET session_uuid=excluded.session_uuid,phase=excluded.phase,snapshot=excluded.snapshot,updated_at=excluded.updated_at")) {
            p.setString(1, player.toString()); p.setString(2, session.toString()); p.setString(3, phase);
            p.setString(4, snapshot); p.setLong(5, System.currentTimeMillis()); p.executeUpdate();
        }
    }

    public synchronized Optional<StoredState> state(UUID player) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("SELECT session_uuid,phase,snapshot FROM player_state WHERE player_uuid=?")) {
            p.setString(1, player.toString());
            try (ResultSet r = p.executeQuery()) { return r.next() ? Optional.of(new StoredState(UUID.fromString(r.getString(1)), r.getString(2), r.getString(3))) : Optional.empty(); }
        }
    }
    public synchronized void deleteState(UUID player) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("DELETE FROM player_state WHERE player_uuid=?")) { p.setString(1, player.toString()); p.executeUpdate(); }
    }
    public synchronized void enqueue(AuditEvent event, String json) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("INSERT OR IGNORE INTO audit_queue(event_id,payload,created_at) VALUES(?,?,?)")) {
            p.setString(1, event.id().toString()); p.setString(2, json); p.setLong(3, event.occurredAt().toEpochMilli()); p.executeUpdate();
        }
    }
    public synchronized List<QueuedEvent> batch(int limit) throws SQLException {
        List<QueuedEvent> result = new ArrayList<>();
        try (PreparedStatement p = connection.prepareStatement("SELECT event_id,payload FROM audit_queue ORDER BY created_at LIMIT ?")) {
            p.setInt(1, limit); try (ResultSet r = p.executeQuery()) { while (r.next()) result.add(new QueuedEvent(r.getString(1), r.getString(2))); }
        }
        return result;
    }
    public synchronized void acknowledge(Collection<String> ids) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("DELETE FROM audit_queue WHERE event_id=?")) { for (String id : ids) { p.setString(1,id); p.addBatch(); } p.executeBatch(); }
    }
    public synchronized long queueSize() throws SQLException { try (Statement s=connection.createStatement(); ResultSet r=s.executeQuery("SELECT COUNT(*) FROM audit_queue")) { return r.next()?r.getLong(1):0; } }
    @Override public synchronized void close() { try { if (connection != null) connection.close(); } catch (SQLException ignored) {} }
    public record StoredState(UUID sessionId, String phase, String snapshot) {}
    public record QueuedEvent(String id, String payload) {}
}
