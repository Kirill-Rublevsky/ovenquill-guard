package ru.ovenquill.guard.common;

public enum RiskLevel { NORMAL, SUSPICIOUS, DANGEROUS }
