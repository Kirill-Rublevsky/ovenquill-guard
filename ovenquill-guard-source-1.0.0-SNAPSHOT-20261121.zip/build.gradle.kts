plugins { id("com.gradleup.shadow") }

repositories { maven("https://repo.papermc.io/repository/maven-public/") }

dependencies {
    implementation(project(":guard-common"))
    implementation("org.xerial:sqlite-jdbc:3.51.1.0")
    compileOnly("io.papermc.paper:paper-api:26.2.build.+")
}

tasks.shadowJar {
    archiveClassifier.set("")
    relocate("org.sqlite", "ru.ovenquill.guard.libs.sqlite")
}
tasks.build { dependsOn(tasks.shadowJar) }
