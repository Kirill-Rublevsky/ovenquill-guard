package ru.ovenquill.guard.common;

import java.util.Locale;
import java.util.Set;

public final class RiskClassifier {
    private static final Set<String> DANGEROUS = Set.of("op", "deop", "lp", "luckperms", "give", "clear", "gamemode", "co", "coreprotect", "we", "worldedit");
    private RiskClassifier() {}

    public static RiskLevel command(String raw) {
        if (raw == null || raw.isBlank()) return RiskLevel.NORMAL;
        String cmd = raw.replaceFirst("^/", "").split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        if (cmd.contains(":")) cmd = cmd.substring(cmd.indexOf(':') + 1);
        return DANGEROUS.contains(cmd) ? RiskLevel.DANGEROUS : RiskLevel.NORMAL;
    }
}
