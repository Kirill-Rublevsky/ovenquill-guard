package ru.ovenquill.guard.velocity;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Plugin(id="ovenquill-guard-bridge",name="OVENQUILL Guard Bridge",version="1.0.0-SNAPSHOT",authors={"OVENQUILL"})
public final class GuardVelocityPlugin {
    private static final MinecraftChannelIdentifier CHANNEL=MinecraftChannelIdentifier.from("ovenquill:guard");
    private final Set<UUID> active=ConcurrentHashMap.newKeySet();
    @Inject public GuardVelocityPlugin(ProxyServer proxy, Logger logger){proxy.getChannelRegistrar().register(CHANNEL);logger.info("OVENQUILL Guard Bridge включён");}
    @Subscribe public void message(PluginMessageEvent e){if(!e.getIdentifier().equals(CHANNEL)||!(e.getSource() instanceof com.velocitypowered.api.proxy.ServerConnection server))return;e.setResult(PluginMessageEvent.ForwardResult.handled());String data=new String(e.getData(),java.nio.charset.StandardCharsets.UTF_8);String[] p=data.split(":",2);if(p.length!=2)return;try{UUID id=UUID.fromString(p[1]);if("ACTIVE".equals(p[0]))active.add(id);else if("INACTIVE".equals(p[0]))active.remove(id);}catch(IllegalArgumentException ignored){}}
    @Subscribe public void switchServer(ServerPreConnectEvent e){if(e.getPlayer().getCurrentServer().isPresent()&&active.contains(e.getPlayer().getUniqueId())){e.setResult(ServerPreConnectEvent.ServerResult.denied());e.getPlayer().sendMessage(Component.text("✦ OVENQUILL GUARD | Перед переходом выключи режим модератора"));}}
}
