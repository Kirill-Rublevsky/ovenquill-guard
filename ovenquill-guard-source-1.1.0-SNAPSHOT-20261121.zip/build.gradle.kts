plugins {
    java
    id("com.gradleup.shadow") version "9.2.2" apply false
}

allprojects {
    group = "ru.ovenquill.guard"
    version = "1.1.0-SNAPSHOT"
    repositories { mavenCentral() }
}

subprojects {
    apply(plugin = "java")
    tasks.withType<JavaCompile>().configureEach {
        options.encoding = "UTF-8"
        options.release.set(25)
    }
    tasks.withType<Test>().configureEach { useJUnitPlatform() }
}
