package ru.ovenquill.guard.paper.xray;

import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
import java.util.regex.*;

public final class XrayCommand implements CommandExecutor {
    private final XrayService service; public XrayCommand(XrayService service){this.service=service;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!(sender instanceof Player p)){sender.sendMessage("Только для игрока");return true;}
        if(args.length==1&&args[0].equalsIgnoreCase("stop")){if(!service.stop(p,true))p.sendMessage("§c✦ GUARD | Просмотр не запущен");return true;}
        if(args.length<2){p.sendMessage("§d/xray <алмаз|незерит|материал> <время> §7(например: /xray алмаз 2h)");return true;}
        try{service.start(p,materials(args[0]),seconds(args[1]));}catch(Exception e){p.sendMessage("§c✦ GUARD | "+e.getMessage());}return true;
    }
    private static Set<Material> materials(String raw){String key=raw.toLowerCase(Locale.ROOT);return switch(key){case"алмаз","diamond","diamonds"->Set.of(Material.DIAMOND_ORE,Material.DEEPSLATE_DIAMOND_ORE);case"незерит","netherite","древние_обломки","ancient_debris"->Set.of(Material.ANCIENT_DEBRIS);default->{Material m=Material.matchMaterial(raw);if(m==null||!m.isBlock())throw new IllegalArgumentException("Неизвестный блок: "+raw);yield Set.of(m);}};}
    private static int seconds(String raw){Matcher m=Pattern.compile("^(\\d+)([smhdсмчд]?)$",Pattern.CASE_INSENSITIVE).matcher(raw);if(!m.matches())throw new IllegalArgumentException("Время: 30m, 2h или 1d");long n=Long.parseLong(m.group(1));String u=m.group(2).toLowerCase(Locale.ROOT);long mult=switch(u){case"s","с"->1;case"h","ч"->3600;case"d","д"->86400;default->60;};long value=n*mult;if(value<1||value>2_592_000)throw new IllegalArgumentException("Допустимый период: до 30 дней");return(int)value;}
}
