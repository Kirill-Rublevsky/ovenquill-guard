package ru.ovenquill.guard.paper.xray;

import net.coreprotect.CoreProtect;
import net.coreprotect.CoreProtectAPI;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.Plugin;
import ru.ovenquill.guard.common.RiskLevel;
import ru.ovenquill.guard.paper.GuardPlugin;
import ru.ovenquill.guard.paper.audit.AuditService;
import ru.ovenquill.guard.paper.mode.ModModeService;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class XrayService implements Listener {
    private final GuardPlugin plugin; private final ModModeService mode; private final AuditService audit;
    private final Map<UUID, ReplaySession> sessions = new ConcurrentHashMap<>();
    private final DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss").withZone(ZoneId.systemDefault());
    public XrayService(GuardPlugin plugin, ModModeService mode, AuditService audit){this.plugin=plugin;this.mode=mode;this.audit=audit;}

    public void start(Player player, Set<Material> materials, int seconds) {
        if (!mode.isActive(player)) throw new IllegalStateException("Сначала включи MOD MODE командой /mod");
        CoreProtectAPI api = api(); if (api == null) throw new IllegalStateException("CoreProtect API недоступен");
        stop(player, true);
        Location returnLocation=player.getLocation().clone(); GameMode returnMode=player.getGameMode();
        player.sendMessage(Component.text("✦ GUARD | Ищу добычу в CoreProtect…"));
        int max=plugin.getConfig().getInt("xray.max-results",1000);
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin,()->{
            List<String[]> found=api.performLookup(seconds,null,null,new ArrayList<>(materials),null,List.of(0),0,null);
            List<XrayPoint> points=new ArrayList<>();
            if(found!=null) for(String[] row:found){CoreProtectAPI.ParseResult r=api.parseResult(row);if(r.getType()!=null&&materials.contains(r.getType())){points.add(new XrayPoint(r.worldName(),r.getX(),r.getY(),r.getZ(),r.getType(),r.getPlayer(),r.getTimestamp()));if(points.size()>=max)break;}}
            Collections.reverse(points);
            plugin.getServer().getScheduler().runTask(plugin,()->{
                if(!player.isOnline())return;
                if(points.isEmpty()){player.sendMessage(Component.text("✦ GUARD | За выбранное время добыча не найдена"));return;}
                sessions.put(player.getUniqueId(),new ReplaySession(points,0,returnLocation,returnMode)); player.setGameMode(GameMode.SPECTATOR); show(player);
                audit.record(player,"XRAY_REPLAY_START",materials.toString(),"SUCCESS",RiskLevel.NORMAL,"Просмотр CoreProtect","{\"results\":"+points.size()+"}");
            });
        });
    }
    public boolean stop(Player player, boolean restore){ReplaySession s=sessions.remove(player.getUniqueId());if(s==null)return false;if(restore&&player.isOnline()){player.setGameMode(s.returnMode());player.teleport(s.returnLocation());player.sendMessage(Component.text("✦ GUARD | Просмотр Xray завершён"));}return true;}
    private void next(Player player){ReplaySession s=sessions.get(player.getUniqueId());if(s==null)return;int next=s.index()+1;if(next>=s.points().size()){stop(player,true);player.sendMessage(Component.text("✦ GUARD | Достигнут конец списка"));return;}sessions.put(player.getUniqueId(),new ReplaySession(s.points(),next,s.returnLocation(),s.returnMode()));show(player);}
    private void show(Player p){ReplaySession s=sessions.get(p.getUniqueId());XrayPoint point=s.points().get(s.index());World world=Bukkit.getWorld(point.world());if(world==null){p.sendMessage(Component.text("✦ GUARD | Мир недоступен: "+point.world()));next(p);return;}p.teleport(new Location(world,point.x()+0.5,point.y()+1.2,point.z()+0.5));p.sendMessage(Component.text("✦ XRAY "+(s.index()+1)+"/"+s.points().size()+" | "+point.material()+" | сломал "+point.player()+" | "+timeFormat.format(Instant.ofEpochMilli(point.timestamp()))+" | "+point.world()+" "+point.x()+" "+point.y()+" "+point.z()));p.sendActionBar(Component.text("ПКМ — следующая запись • /xray stop — выход"));}
    private CoreProtectAPI api(){Plugin p=plugin.getServer().getPluginManager().getPlugin("CoreProtect");if(!(p instanceof CoreProtect cp))return null;CoreProtectAPI api=cp.getAPI();return api.isEnabled()&&api.APIVersion()>=9?api:null;}
    @EventHandler(priority=EventPriority.HIGHEST) public void click(PlayerInteractEvent e){if(e.getHand()!=EquipmentSlot.HAND||!sessions.containsKey(e.getPlayer().getUniqueId()))return;if(e.getAction()==Action.RIGHT_CLICK_AIR||e.getAction()==Action.RIGHT_CLICK_BLOCK){e.setCancelled(true);next(e.getPlayer());}}
    @EventHandler public void quit(PlayerQuitEvent e){stop(e.getPlayer(),false);}
    private record XrayPoint(String world,int x,int y,int z,Material material,String player,long timestamp){}
    private record ReplaySession(List<XrayPoint> points,int index,Location returnLocation,GameMode returnMode){}
}
