plugins { id("com.gradleup.shadow") }

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
    maven("https://maven.playpro.com/")
}

dependencies {
    implementation(project(":guard-common"))
    implementation("org.xerial:sqlite-jdbc:3.51.1.0")
    compileOnly("io.papermc.paper:paper-api:26.2.build.+")
    compileOnly("net.luckperms:api:5.4")
    compileOnly("net.coreprotect:coreprotect:24.1")
}

tasks.shadowJar {
    archiveClassifier.set("")
    relocate("org.sqlite", "ru.ovenquill.guard.libs.sqlite")
}
tasks.build { dependsOn(tasks.shadowJar) }
