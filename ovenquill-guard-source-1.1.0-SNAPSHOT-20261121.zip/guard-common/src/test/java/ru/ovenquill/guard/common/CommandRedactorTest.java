package ru.ovenquill.guard.common;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CommandRedactorTest {
    @Test void masksSecrets() { assertEquals("/login ***", CommandRedactor.redact("/login hunter2")); }
    @Test void keepsOrdinaryCommands() { assertEquals("/tp Steve", CommandRedactor.redact("/tp Steve")); }
}
