package ru.ovenquill.guard.common;

import java.time.Instant;
import java.util.UUID;

public record AuditEvent(
        UUID id, String serverId, UUID sessionId, UUID actorId, String type,
        Instant occurredAt, String world, double x, double y, double z,
        String subject, String result, RiskLevel risk, String reason, String detailsJson) {
    public static AuditEvent create(String serverId, UUID sessionId, UUID actorId, String type,
                                    String world, double x, double y, double z, String subject,
                                    String result, RiskLevel risk, String reason, String detailsJson) {
        return new AuditEvent(UUID.randomUUID(), serverId, sessionId, actorId, type, Instant.now(),
                world, x, y, z, subject, result, risk, reason, detailsJson);
    }
}
