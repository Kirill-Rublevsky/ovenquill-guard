package ru.ovenquill.guard.paper.mode;

import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;

public final class ModModeListener implements Listener {
    private final ModModeService mode; public ModModeListener(ModModeService mode){this.mode=mode;}
    @EventHandler(priority=EventPriority.HIGHEST) public void inventoryClick(InventoryClickEvent e){if(e.getWhoClicked() instanceof org.bukkit.entity.Player p && mode.isActive(p) && (mode.isTool(e.getCurrentItem())||mode.isTool(e.getCursor())))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST) public void inventoryDrag(InventoryDragEvent e){if(e.getWhoClicked() instanceof org.bukkit.entity.Player p && mode.isActive(p) && mode.isTool(e.getOldCursor()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST) public void drop(PlayerDropItemEvent e){if(mode.isActive(e.getPlayer())&&mode.isTool(e.getItemDrop().getItemStack()))e.setCancelled(true);}
    @EventHandler(priority=EventPriority.HIGHEST) public void swap(PlayerSwapHandItemsEvent e){if(mode.isActive(e.getPlayer())&&(mode.isTool(e.getMainHandItem())||mode.isTool(e.getOffHandItem())))e.setCancelled(true);}
    @EventHandler public void join(PlayerJoinEvent e){mode.recoverIfNecessary(e.getPlayer());}
    @EventHandler public void quit(PlayerQuitEvent e){if(mode.isActive(e.getPlayer()))try{mode.disable(e.getPlayer());}catch(Exception ignored){}}
    @EventHandler public void death(PlayerDeathEvent e){if(mode.isActive(e.getEntity())){e.getDrops().removeIf(mode::isTool);e.setKeepInventory(true);}}
    @EventHandler public void interact(PlayerInteractEvent e){if(!mode.isActive(e.getPlayer())||!mode.isTool(e.getItem()))return;if(e.getItem().getType()==org.bukkit.Material.BARRIER){e.setCancelled(true);try{mode.disable(e.getPlayer());}catch(Exception ex){e.getPlayer().sendMessage("§cОшибка восстановления: "+ex.getMessage());}}}
}
