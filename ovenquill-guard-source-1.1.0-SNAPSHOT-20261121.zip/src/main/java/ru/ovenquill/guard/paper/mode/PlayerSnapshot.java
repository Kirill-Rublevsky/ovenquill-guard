package ru.ovenquill.guard.paper.mode;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import java.util.*;

final class PlayerSnapshot {
    static String capture(Player p) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("inventory", p.getInventory().getStorageContents()); y.set("armor", p.getInventory().getArmorContents());
        y.set("offhand", p.getInventory().getItemInOffHand()); y.set("slot", p.getInventory().getHeldItemSlot());
        y.set("exp", p.getExp()); y.set("level", p.getLevel()); y.set("health", p.getHealth());
        var max = p.getAttribute(Attribute.MAX_HEALTH); y.set("max-health", max == null ? 20.0 : max.getBaseValue());
        y.set("food", p.getFoodLevel()); y.set("saturation", p.getSaturation()); y.set("gamemode", p.getGameMode().name());
        Location l=p.getLocation(); y.set("world", l.getWorld().getName()); y.set("x",l.x()); y.set("y",l.y()); y.set("z",l.z()); y.set("yaw",l.getYaw()); y.set("pitch",l.getPitch());
        y.set("fly-speed",p.getFlySpeed()); y.set("allow-flight",p.getAllowFlight()); y.set("flying",p.isFlying()); y.set("effects",new ArrayList<>(p.getActivePotionEffects()));
        return y.saveToString();
    }
    @SuppressWarnings("unchecked") static void restore(Player p, String raw) throws Exception {
        YamlConfiguration y = new YamlConfiguration(); y.loadFromString(raw);
        p.getInventory().clear();
        List<ItemStack> inv=(List<ItemStack>)(List<?>)y.getList("inventory",List.of()); p.getInventory().setStorageContents(inv.toArray(ItemStack[]::new));
        List<ItemStack> armor=(List<ItemStack>)(List<?>)y.getList("armor",List.of()); p.getInventory().setArmorContents(armor.toArray(ItemStack[]::new));
        p.getInventory().setItemInOffHand(y.getItemStack("offhand",new ItemStack(Material.AIR))); p.getInventory().setHeldItemSlot(y.getInt("slot"));
        p.setExp((float)y.getDouble("exp")); p.setLevel(y.getInt("level"));
        var max=p.getAttribute(Attribute.MAX_HEALTH); if(max!=null) max.setBaseValue(y.getDouble("max-health",20)); p.setHealth(Math.min(y.getDouble("health",20), max==null?20:max.getValue()));
        p.setFoodLevel(y.getInt("food",20)); p.setSaturation((float)y.getDouble("saturation",5)); p.setGameMode(GameMode.valueOf(y.getString("gamemode","SURVIVAL")));
        World world=Bukkit.getWorld(Objects.requireNonNull(y.getString("world"))); if(world==null) throw new IllegalStateException("Мир снимка недоступен");
        p.teleport(new Location(world,y.getDouble("x"),y.getDouble("y"),y.getDouble("z"),(float)y.getDouble("yaw"),(float)y.getDouble("pitch")));
        p.setFlySpeed((float)y.getDouble("fly-speed",0.1)); p.setAllowFlight(y.getBoolean("allow-flight")); if(p.getAllowFlight()) p.setFlying(y.getBoolean("flying"));
        p.getActivePotionEffects().forEach(e->p.removePotionEffect(e.getType())); for(Object e:y.getList("effects",List.of())) if(e instanceof PotionEffect pe)p.addPotionEffect(pe);
    }
}
