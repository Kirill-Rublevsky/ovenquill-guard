package ru.ovenquill.guard.common;

import java.util.Locale;
import java.util.Set;

public final class CommandRedactor {
    private static final Set<String> SENSITIVE = Set.of("login", "l", "register", "reg", "changepassword", "password", "token");
    private CommandRedactor() {}

    public static String redact(String raw) {
        String value = raw == null ? "" : raw.trim();
        String noSlash = value.startsWith("/") ? value.substring(1) : value;
        String command = noSlash.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int namespace = command.indexOf(':');
        if (namespace >= 0) command = command.substring(namespace + 1);
        return SENSITIVE.contains(command) ? "/" + command + " ***" : value;
    }
}
