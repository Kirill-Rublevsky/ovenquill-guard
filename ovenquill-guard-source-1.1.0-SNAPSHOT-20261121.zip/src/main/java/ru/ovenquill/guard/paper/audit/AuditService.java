package ru.ovenquill.guard.paper.audit;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import ru.ovenquill.guard.common.*;
import ru.ovenquill.guard.paper.GuardPlugin;
import ru.ovenquill.guard.paper.storage.GuardDatabase;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

public final class AuditService implements AutoCloseable {
    private final GuardPlugin plugin; private final GuardDatabase db; private final ExecutorService worker=Executors.newSingleThreadExecutor(Thread.ofVirtual().name("guard-audit-",0).factory());
    private final HttpClient http=HttpClient.newBuilder().executor(worker).connectTimeout(Duration.ofSeconds(5)).build();
    public AuditService(GuardPlugin plugin,GuardDatabase db){this.plugin=plugin;this.db=db;}
    public void start(){plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin,this::flush,100L,100L);}
    public void record(Player p,String type,String subject,String result,RiskLevel risk,String reason,String details){
        Location l=p.getLocation(); AuditEvent e=AuditEvent.create(plugin.getConfig().getString("guard.server-id","unknown"),null,p.getUniqueId(),type,l.getWorld().getName(),l.x(),l.y(),l.z(),subject,result,risk,reason,details);
        worker.execute(()->{try{db.enqueue(e,json(e));}catch(Exception ex){plugin.getLogger().severe("Потеря события аудита предотвращена не была: "+ex.getMessage());}});
    }
    private void flush(){
        if(!plugin.getConfig().getBoolean("api.enabled"))return;
        try{List<GuardDatabase.QueuedEvent> batch=db.batch(plugin.getConfig().getInt("api.batch-size",100));if(batch.isEmpty())return;
            String token=System.getenv(plugin.getConfig().getString("api.token-environment-variable","OVENQUILL_GUARD_TOKEN"));if(token==null||token.isBlank())return;
            String body="["+String.join(",",batch.stream().map(GuardDatabase.QueuedEvent::payload).toList())+"]";
            HttpRequest request=HttpRequest.newBuilder(URI.create(plugin.getConfig().getString("api.url")+"/events/batch")).timeout(Duration.ofSeconds(plugin.getConfig().getInt("api.request-timeout-seconds",5))).header("Authorization","Bearer "+token).header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(body)).build();
            HttpResponse<Void> response=http.send(request,HttpResponse.BodyHandlers.discarding());if(response.statusCode()>=200&&response.statusCode()<300)db.acknowledge(batch.stream().map(GuardDatabase.QueuedEvent::id).toList());
        }catch(Exception e){plugin.getLogger().warning("Guard API недоступен; события остаются в очереди: "+e.getMessage());}
    }
    private static String q(String s){return "\""+(s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"))+"\"";}
    private static String json(AuditEvent e){return "{\"id\":"+q(e.id().toString())+",\"server_id\":"+q(e.serverId())+",\"actor_uuid\":"+q(e.actorId().toString())+",\"type\":"+q(e.type())+",\"occurred_at\":"+q(e.occurredAt().toString())+",\"world\":"+q(e.world())+",\"x\":"+e.x()+",\"y\":"+e.y()+",\"z\":"+e.z()+",\"subject\":"+q(e.subject())+",\"result\":"+q(e.result())+",\"risk\":"+q(e.risk().name())+",\"reason\":"+q(e.reason())+",\"details\":"+e.detailsJson()+"}";}
    @Override public void close(){worker.shutdown();try{worker.awaitTermination(3,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
