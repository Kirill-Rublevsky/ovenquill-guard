package ru.ovenquill.guard.paper.permission;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;
import ru.ovenquill.guard.paper.GuardPlugin;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LuckPermsProfileService {
    private final GuardPlugin plugin;
    private final LuckPerms luckPerms;
    private final String group;
    private final Map<UUID, PermissionAttachment> activeAttachments = new ConcurrentHashMap<>();

    public LuckPermsProfileService(GuardPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms")) {
            throw new IllegalStateException("LuckPerms обязателен для MOD MODE");
        }
        this.luckPerms = LuckPermsProvider.get();
        this.group = plugin.getConfig().getString("permissions.moderator-group", "ovenquill-moderator");
        if (luckPerms.getGroupManager().getGroup(group) == null) {
            luckPerms.getGroupManager().createAndLoadGroup(group).join();
            plugin.getLogger().warning("Группа LuckPerms была создана автоматически: " + group
                    + ". Добавьте в неё разрешения функций модератора.");
        }
    }

    public void activate(Player player) {
        var lpGroup = luckPerms.getGroupManager().getGroup(group);
        if (lpGroup == null) throw new IllegalStateException("Группа LuckPerms не найдена: " + group);
        var queryOptions = luckPerms.getContextManager().getQueryOptions(player);
        Map<String, Boolean> permissions = lpGroup.getCachedData().getPermissionData(queryOptions).getPermissionMap();
        PermissionAttachment attachment = player.addAttachment(plugin);
        permissions.forEach(attachment::setPermission);
        activeAttachments.put(player.getUniqueId(), attachment);
        player.recalculatePermissions();
    }

    public void deactivate(Player player) {
        PermissionAttachment attachment = activeAttachments.remove(player.getUniqueId());
        if (attachment != null) player.removeAttachment(attachment);
        player.recalculatePermissions();
    }

    public String group() { return group; }
}
