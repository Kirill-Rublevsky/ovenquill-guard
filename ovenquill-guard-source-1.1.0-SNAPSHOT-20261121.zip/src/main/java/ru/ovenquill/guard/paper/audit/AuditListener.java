package ru.ovenquill.guard.paper.audit;

import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.player.*;
import ru.ovenquill.guard.common.*;
import ru.ovenquill.guard.paper.mode.ModModeService;

public final class AuditListener implements Listener {
    private final AuditService audit;private final ModModeService mode;public AuditListener(AuditService a,ModModeService m){audit=a;mode=m;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void command(PlayerCommandPreprocessEvent e){if(mode.isActive(e.getPlayer())){String redacted=CommandRedactor.redact(e.getMessage());RiskLevel risk=RiskClassifier.command(e.getMessage());audit.record(e.getPlayer(),"COMMAND",redacted,"SUBMITTED",risk,risk==RiskLevel.DANGEROUS?"Опасная команда":"Команда введена","{}");}}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void breakBlock(BlockBreakEvent e){if(mode.isActive(e.getPlayer()))audit.record(e.getPlayer(),"BLOCK_BREAK",e.getBlock().getType().name(),"SUCCESS",RiskLevel.NORMAL,"Изменение блока","{}");}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void placeBlock(BlockPlaceEvent e){if(mode.isActive(e.getPlayer()))audit.record(e.getPlayer(),"BLOCK_PLACE",e.getBlock().getType().name(),"SUCCESS",RiskLevel.NORMAL,"Изменение блока","{}");}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void interact(PlayerInteractEvent e){if(mode.isActive(e.getPlayer())&&e.getClickedBlock()!=null&&e.getClickedBlock().getState() instanceof Container)audit.record(e.getPlayer(),"CONTAINER_OPEN",e.getClickedBlock().getType().name(),"OBSERVED",RiskLevel.NORMAL,"Контейнер открыт","{}");}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void teleport(PlayerTeleportEvent e){if(mode.isActive(e.getPlayer()))audit.record(e.getPlayer(),"TELEPORT",e.getCause().name(),"SUCCESS",RiskLevel.NORMAL,"Телепортация","{}");}
}
