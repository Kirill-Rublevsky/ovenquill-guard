package ru.ovenquill.guard.paper.mode;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import ru.ovenquill.guard.common.RiskLevel;
import ru.ovenquill.guard.paper.GuardPlugin;
import ru.ovenquill.guard.paper.audit.AuditService;
import ru.ovenquill.guard.paper.storage.GuardDatabase;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ModModeService {
    private final GuardPlugin plugin; private final GuardDatabase db; private final AuditService audit;
    private final Map<UUID,UUID> active=new ConcurrentHashMap<>(); private final NamespacedKey toolKey;
    public ModModeService(GuardPlugin plugin, GuardDatabase db, AuditService audit){this.plugin=plugin;this.db=db;this.audit=audit;toolKey=new NamespacedKey(plugin,"moderator-tool");}
    public boolean isActive(Player p){return active.containsKey(p.getUniqueId());} public UUID session(Player p){return active.get(p.getUniqueId());}
    public boolean isTool(ItemStack item){return item!=null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(toolKey,PersistentDataType.STRING);}
    public synchronized void enable(Player p) throws Exception {
        if(isActive(p)) throw new IllegalStateException("Режим уже включён");
        if(db.state(p.getUniqueId()).isPresent()) throw new IllegalStateException("Требуется восстановление состояния");
        UUID session=UUID.randomUUID(); String snapshot=PlayerSnapshot.capture(p); db.saveState(p.getUniqueId(),session,"ENTERING",snapshot);
        p.getInventory().clear(); p.getInventory().setArmorContents(new ItemStack[4]); p.getInventory().setItemInOffHand(new ItemStack(Material.AIR)); p.setGameMode(GameMode.SPECTATOR);
        setTool(p,0,Material.COMPASS,"Телепортация","teleport"); setTool(p,1,Material.WRITABLE_BOOK,"История CoreProtect","coreprotect"); setTool(p,2,Material.CHEST,"Инвентарь игрока","inventory");
        setTool(p,3,Material.ENDER_EYE,"Наблюдение","spectate"); setTool(p,4,Material.BLAZE_ROD,"Проверка","inspect"); setTool(p,5,Material.DIAMOND_PICKAXE,"Xray-анализ","xray"); setTool(p,6,Material.CLOCK,"Активность","activity"); setTool(p,8,Material.BARRIER,"Выход из MOD MODE","exit");
        active.put(p.getUniqueId(),session); sendBridge(p,"ACTIVE"); db.saveState(p.getUniqueId(),session,"ACTIVE",snapshot); audit.record(p,"MOD_MODE_START","session:"+session,"SUCCESS",RiskLevel.NORMAL,"Режим включён","{}");
        p.sendMessage(Component.text("✦ OVENQUILL GUARD | Режим модератора включён"));
    }
    public synchronized void disable(Player p) throws Exception {
        var stored=db.state(p.getUniqueId()).orElseThrow(()->new IllegalStateException("Снимок состояния не найден"));
        db.saveState(p.getUniqueId(),stored.sessionId(),"EXITING",stored.snapshot()); active.remove(p.getUniqueId()); sendBridge(p,"INACTIVE");
        p.getInventory().clear(); PlayerSnapshot.restore(p,stored.snapshot()); db.deleteState(p.getUniqueId());
        audit.record(p,"MOD_MODE_END","session:"+stored.sessionId(),"SUCCESS",RiskLevel.NORMAL,"Режим выключен","{}"); p.sendMessage(Component.text("✦ OVENQUILL GUARD | Игровое состояние восстановлено"));
    }
    public void recoverIfNecessary(Player p){
        try{var s=db.state(p.getUniqueId()); if(s.isEmpty())return; active.remove(p.getUniqueId()); PlayerSnapshot.restore(p,s.get().snapshot()); db.deleteState(p.getUniqueId()); p.sendMessage(Component.text("✦ OVENQUILL GUARD | Состояние восстановлено после сбоя"));}
        catch(Exception e){plugin.getLogger().severe("Не удалось восстановить "+p.getUniqueId()+": "+e.getMessage()); p.kick(Component.text("OVENQUILL GUARD: требуется ручное восстановление"));}
    }
    private void setTool(Player p,int slot,Material type,String name,String id){ItemStack item=new ItemStack(type); item.editMeta(m->{m.displayName(Component.text("✦ "+name));m.getPersistentDataContainer().set(toolKey,PersistentDataType.STRING,id);});p.getInventory().setItem(slot,item);}
    private void sendBridge(Player p,String state){p.sendPluginMessage(plugin,"ovenquill:guard",(state+":"+p.getUniqueId()).getBytes(java.nio.charset.StandardCharsets.UTF_8));}
}
