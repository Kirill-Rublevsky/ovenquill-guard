rootProject.name = "ovenquill-guard"
include("guard-common", "guard-paper", "guard-velocity")
