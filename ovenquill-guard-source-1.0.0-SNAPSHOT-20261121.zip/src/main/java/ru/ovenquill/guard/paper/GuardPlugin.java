package ru.ovenquill.guard.paper;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import ru.ovenquill.guard.paper.audit.AuditListener;
import ru.ovenquill.guard.paper.audit.AuditService;
import ru.ovenquill.guard.paper.command.GuardCommand;
import ru.ovenquill.guard.paper.command.ModCommand;
import ru.ovenquill.guard.paper.mode.ModModeListener;
import ru.ovenquill.guard.paper.mode.ModModeService;
import ru.ovenquill.guard.paper.storage.GuardDatabase;

public final class GuardPlugin extends JavaPlugin {
    private GuardDatabase database;
    private AuditService audit;
    private ModModeService modMode;

    @Override public void onEnable() {
        saveDefaultConfig();
        try {
            database = new GuardDatabase(getDataFolder().toPath().resolve("guard.db"));
            database.initialize();
        } catch (Exception e) {
            getLogger().severe("Не удалось открыть безопасное хранилище: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        audit = new AuditService(this, database);
        modMode = new ModModeService(this, database, audit);
        getServer().getMessenger().registerOutgoingPluginChannel(this, "ovenquill:guard");
        bind("mod", new ModCommand(modMode));
        bind("guard", new GuardCommand(this, database, modMode));
        getServer().getPluginManager().registerEvents(new ModModeListener(modMode), this);
        getServer().getPluginManager().registerEvents(new AuditListener(audit, modMode), this);
        audit.start();
        getServer().getOnlinePlayers().forEach(modMode::recoverIfNecessary);
        getLogger().info("OVENQUILL GUARD включён; server-id=" + getConfig().getString("guard.server-id"));
    }

    private void bind(String name, Object executor) {
        PluginCommand command = getCommand(name);
        if (command == null) throw new IllegalStateException("Команда отсутствует в plugin.yml: " + name);
        command.setExecutor((org.bukkit.command.CommandExecutor) executor);
    }

    @Override public void onDisable() {
        if (audit != null) audit.close();
        if (database != null) database.close();
    }
}
