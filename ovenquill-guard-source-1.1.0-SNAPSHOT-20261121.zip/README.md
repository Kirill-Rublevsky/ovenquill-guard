# OVENQUILL GUARD

Система безопасной модерации и аудита для приватного Minecraft-проекта OVENQUILL. Проект предназначен для Paper/Purpur 26.2 и сети Velocity.

> Текущая версия — `1.1.0-SNAPSHOT`. Это не полная реализация всего ТЗ v1.0.

## Модули

- `guard-common` — события, маскирование секретов и оценка риска.
- `guard-paper` — MOD MODE, восстановление, LuckPerms-профиль, CoreProtect Xray Replay, аудит и SQLite-очередь.
- `guard-velocity` — блокировка межсерверного перехода при активном MOD MODE.

## Требования и сборка

- JDK 25.
- Gradle 9.2+ (или сгенерированный wrapper).
- Paper/Purpur 26.2.

```powershell
gradle wrapper
.\gradlew.bat clean test build
```

Готовые JAR находятся в `guard-paper/build/libs` и `guard-velocity/build/libs`.

## Установка

1. Поместите `guard-paper-1.1.0-SNAPSHOT.jar` в папку `plugins` каждого Paper/Purpur backend.
2. Поместите `ovenquill-guard-velocity-1.0.0-SNAPSHOT.jar` в папку `plugins` Velocity.
3. Перезапустите серверы.
4. Укажите уникальный `guard.server-id` в конфигурации каждого backend.
5. Настройте Velocity modern forwarding и запретите прямые подключения к backend на сетевом уровне.

## Доступ через LuckPerms

Команда `/mod` не выдаётся всем игрокам и не требует OP. Доступ назначается владельцем через LuckPerms:

```text
/lp user <ник> permission set ovenquill.guard.mod.use true
```

Отзыв доступа:

```text
/lp user <ник> permission unset ovenquill.guard.mod.use
```

Просмотр состояния плагина выдаётся отдельно:

```text
/lp user <ник> permission set ovenquill.guard.admin.status true
```

Постоянное право на `/mod` разрешает только включение режима. Оно не выдаёт OP, wildcard `*` или сторонние административные команды.

Создайте отдельную группу, разрешения которой должны работать только во время MOD MODE:

```text
/lp creategroup ovenquill-moderator
/lp group ovenquill-moderator permission set essentials.tp true
/lp group ovenquill-moderator permission set ovenquill.guard.xray.inspect true
```

Имя группы задаётся в `permissions.moderator-group`. При `/mod on` GUARD подключает итоговые разрешения этой группы игроку через временный attachment. Постоянное наследование группы не записывается. При `/mod off`, выходе или восстановлении разрешения снимаются.

## Xray Replay через CoreProtect

```text
/xray алмаз 2h
/xray незерит 30m
/xray diamond_ore 1d
/xray stop
```

`алмаз` включает `DIAMOND_ORE` и `DEEPSLATE_DIAMOND_ORE`; `незерит` ищет `ANCIENT_DEBRIS`. Поиск выполняется асинхронно в CoreProtect. Модератор переходит в spectator и телепортируется к первой записи. ПКМ открывает следующую; чат показывает материал, игрока, дату, время, мир и координаты. После конца списка или `/xray stop` возвращаются прежние позиция и режим игры.

## Команды

| Команда | Назначение | Permission |
|---|---|---|
| `/mod` | Переключить MOD MODE | `ovenquill.guard.mod.use` |
| `/mod on` | Включить MOD MODE | `ovenquill.guard.mod.use` |
| `/mod off` | Восстановить игровое состояние | `ovenquill.guard.mod.use` |
| `/mod status` | Показать состояние | `ovenquill.guard.mod.use` |
| `/guard status` | Состояние GUARD и размер очереди | `ovenquill.guard.admin.status` |

## Как работает MOD MODE

Перед переключением плагин синхронно фиксирует исходное состояние в SQLite с `synchronous=FULL` и фазой `ENTERING`. Сохраняются инвентарь, броня, вторая рука, слот, опыт, здоровье, голод, игровой режим, координаты, полёт и эффекты. Только после записи игрок получает служебное состояние.

При выходе запись переводится в `EXITING`, служебные предметы удаляются, исходный снимок восстанавливается и лишь затем удаляется из журнала. После сбоя или reconnect незавершённое состояние автоматически восстанавливается. Если мир снимка недоступен, вход блокируется для ручного восстановления — исходный снимок не перезаписывается.

Служебные предметы помечены через `PersistentDataContainer`. Заблокированы drop, drag, click, swap второй руки и выпадение при смерти.

## Аудит и Guard API

Фиксируются команды модератора, установка и разрушение блоков, открытие контейнеров и телепортации. События сначала попадают в локальную идемпотентную SQLite-очередь и отправляются на CONTROL асинхронными пакетами. HTTP никогда не выполняется в игровом потоке.

Endpoint:

```text
POST /api/v1/guard/events/batch
Authorization: Bearer <machine-token>
```

Команды авторизации (`/login`, `/register`, `/password`, `/token`) маскируются до записи. Опасные команды получают риск `DANGEROUS`. Факт ввода команды помечается как `SUBMITTED`, а не ложно как успешно выполненная операция.

API-ключ передаётся серверу только через переменную окружения `OVENQUILL_GUARD_TOKEN` и не хранится в публичном YAML.

## Velocity Bridge

Paper сообщает Bridge состояния `ACTIVE` и `INACTIVE` через канал `ovenquill:guard`. При активном MOD MODE переход на другой backend отменяется с сообщением:

```text
✦ OVENQUILL GUARD | Перед переходом выключи режим модератора
```

Bridge не хранит и не переносит игровые инвентари.

## Безопасная настройка

1. Установите Paper JAR на каждый backend, Bridge JAR на Velocity.
2. Запустите один раз для генерации `plugins/OVENQUILLGuard/config.yml`.
3. Задайте уникальный `guard.server-id`.
4. Передайте API-ключ через переменную окружения `OVENQUILL_GUARD_TOKEN`; не помещайте его в YAML.
5. Включите `api.enabled` и задайте HTTPS URL OVENQUILL CONTROL.
6. Выдайте только постоянное право `ovenquill.guard.mod.use` нужным сотрудникам.

## Реализованный инкремент

- `/mod on|off|status|help` и `/guard status`.
- SQLite-журнал состояний `ENTERING / ACTIVE / EXITING`.
- Полный снимок игрового состояния и восстановление после reconnect/crash.
- Полностью пустой отдельный инвентарь модератора.
- Временные разрешения из настраиваемой группы LuckPerms.
- Xray Replay по журналу CoreProtect с переходом по точкам правой кнопкой мыши.
- Аудит команд, блоков, контейнеров и телепортаций.
- Маскирование команд авторизации; опасные команды получают `DANGEROUS`.
- Идемпотентная очередь событий и асинхронная пакетная HTTP-доставка.
- Безопасный запрет перехода между backend-серверами через Velocity Bridge.

## Следующие инкременты до полного v1.0

LuckPerms-профили `JUNIOR_MOD / MODERATOR / SENIOR_MOD / OWNER`, расширенный diff контейнеров, CoreProtect API, Xray Monitor/Replay, команды расследования, heartbeat/config API и полный Guard Dashboard. Подозрения Xray не должны приводить к автоматическому наказанию.

## Лицензия и распространение

Проект опубликован для инфраструктуры OVENQUILL. Отдельная open-source лицензия пока не назначена; отсутствие лицензии означает, что права на копирование и распространение автоматически не предоставляются.
